
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, MapPin, Users, DollarSign, Tag, Image as ImageIcon, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';

const CreateEvent = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    date: '',
    startTime: '',
    endTime: '',
    location: '',
    maxAttendees: '',
    ticketType: 'free',
    ticketPrice: '',
    imageUrl: '',
    tags: [] as string[],
    isPublic: true,
    allowChat: true
  });

  const [newTag, setNewTag] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const categories = [
    'Technology',
    'Music',
    'Food & Drink',
    'Sports & Fitness',
    'Business & Professional',
    'Arts & Culture',
    'Education',
    'Health & Wellness',
    'Travel & Outdoor',
    'Community & Social'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) newErrors.title = 'Event title is required';
    if (!formData.description.trim()) newErrors.description = 'Event description is required';
    if (!formData.category) newErrors.category = 'Category is required';
    if (!formData.date) newErrors.date = 'Event date is required';
    if (!formData.startTime) newErrors.startTime = 'Start time is required';
    if (!formData.endTime) newErrors.endTime = 'End time is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.maxAttendees) newErrors.maxAttendees = 'Maximum attendees is required';
    
    if (formData.ticketType === 'paid' && !formData.ticketPrice) {
      newErrors.ticketPrice = 'Ticket price is required for paid events';
    }

    // Date validation
    const eventDate = new Date(formData.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (eventDate < today) {
      newErrors.date = 'Event date cannot be in the past';
    }

    // Time validation
    if (formData.startTime && formData.endTime && formData.startTime >= formData.endTime) {
      newErrors.endTime = 'End time must be after start time';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      console.log('Creating event:', formData);
      // Here you would normally send the data to your API
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Create Your Event</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Bring your community together by creating an amazing event experience
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Basic Information */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl text-gray-800">
                <Tag className="h-5 w-5 text-purple-600" />
                Basic Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="title" className="text-gray-700 font-medium">Event Title *</Label>
                  <Input
                    id="title"
                    name="title"
                    placeholder="Give your event a catchy title"
                    value={formData.title}
                    onChange={handleInputChange}
                    className={`h-12 ${errors.title ? 'border-red-500' : ''}`}
                  />
                  {errors.title && <p className="text-red-500 text-sm">{errors.title}</p>}
                </div>

                <div className="md:col-span-2 space-y-2">
                  <Label htmlFor="description" className="text-gray-700 font-medium">Description *</Label>
                  <Textarea
                    id="description"
                    name="description"
                    placeholder="Describe your event in detail. What can attendees expect?"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={4}
                    className={errors.description ? 'border-red-500' : ''}
                  />
                  {errors.description && <p className="text-red-500 text-sm">{errors.description}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category" className="text-gray-700 font-medium">Category *</Label>
                  <Select value={formData.category} onValueChange={(value) => handleSelectChange('category', value)}>
                    <SelectTrigger className={`h-12 ${errors.category ? 'border-red-500' : ''}`}>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      {categories.map(category => (
                        <SelectItem key={category} value={category.toLowerCase().replace(/ & /g, '-').replace(/ /g, '-')}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.category && <p className="text-red-500 text-sm">{errors.category}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="imageUrl" className="text-gray-700 font-medium">Event Image URL</Label>
                  <div className="relative">
                    <ImageIcon className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="imageUrl"
                      name="imageUrl"
                      placeholder="https://example.com/event-image.jpg"
                      value={formData.imageUrl}
                      onChange={handleInputChange}
                      className="pl-10 h-12"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Date & Time */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl text-gray-800">
                <Calendar className="h-5 w-5 text-purple-600" />
                Date & Time
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="date" className="text-gray-700 font-medium">Event Date *</Label>
                  <Input
                    id="date"
                    name="date"
                    type="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    className={`h-12 ${errors.date ? 'border-red-500' : ''}`}
                    min={new Date().toISOString().split('T')[0]}
                  />
                  {errors.date && <p className="text-red-500 text-sm">{errors.date}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="startTime" className="text-gray-700 font-medium">Start Time *</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="startTime"
                      name="startTime"
                      type="time"
                      value={formData.startTime}
                      onChange={handleInputChange}
                      className={`pl-10 h-12 ${errors.startTime ? 'border-red-500' : ''}`}
                    />
                  </div>
                  {errors.startTime && <p className="text-red-500 text-sm">{errors.startTime}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="endTime" className="text-gray-700 font-medium">End Time *</Label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="endTime"
                      name="endTime"
                      type="time"
                      value={formData.endTime}
                      onChange={handleInputChange}
                      className={`pl-10 h-12 ${errors.endTime ? 'border-red-500' : ''}`}
                    />
                  </div>
                  {errors.endTime && <p className="text-red-500 text-sm">{errors.endTime}</p>}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Location & Capacity */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl text-gray-800">
                <MapPin className="h-5 w-5 text-purple-600" />
                Location & Capacity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="location" className="text-gray-700 font-medium">Event Location *</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="location"
                      name="location"
                      placeholder="Enter venue address or online link"
                      value={formData.location}
                      onChange={handleInputChange}
                      className={`pl-10 h-12 ${errors.location ? 'border-red-500' : ''}`}
                    />
                  </div>
                  {errors.location && <p className="text-red-500 text-sm">{errors.location}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxAttendees" className="text-gray-700 font-medium">Max Attendees *</Label>
                  <div className="relative">
                    <Users className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="maxAttendees"
                      name="maxAttendees"
                      type="number"
                      placeholder="100"
                      value={formData.maxAttendees}
                      onChange={handleInputChange}
                      className={`pl-10 h-12 ${errors.maxAttendees ? 'border-red-500' : ''}`}
                      min="1"
                    />
                  </div>
                  {errors.maxAttendees && <p className="text-red-500 text-sm">{errors.maxAttendees}</p>}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pricing */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl text-gray-800">
                <DollarSign className="h-5 w-5 text-purple-600" />
                Pricing
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">Ticket Type</Label>
                  <Select value={formData.ticketType} onValueChange={(value) => handleSelectChange('ticketType', value)}>
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="free">Free Event</SelectItem>
                      <SelectItem value="paid">Paid Event</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.ticketType === 'paid' && (
                  <div className="space-y-2">
                    <Label htmlFor="ticketPrice" className="text-gray-700 font-medium">Ticket Price *</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <Input
                        id="ticketPrice"
                        name="ticketPrice"
                        type="number"
                        placeholder="25.00"
                        value={formData.ticketPrice}
                        onChange={handleInputChange}
                        className={`pl-10 h-12 ${errors.ticketPrice ? 'border-red-500' : ''}`}
                        min="0"
                        step="0.01"
                      />
                    </div>
                    {errors.ticketPrice && <p className="text-red-500 text-sm">{errors.ticketPrice}</p>}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Tags & Settings */}
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl text-gray-800">
                <Tag className="h-5 w-5 text-purple-600" />
                Tags & Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-gray-700 font-medium">Event Tags</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Add a tag"
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                      className="flex-1"
                    />
                    <Button type="button" onClick={addTag} disabled={!newTag.trim()}>
                      Add
                    </Button>
                  </div>
                  {formData.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {formData.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="bg-purple-100 text-purple-700">
                          {tag}
                          <button
                            type="button"
                            onClick={() => removeTag(tag)}
                            className="ml-2 text-purple-500 hover:text-purple-700"
                          >
                            ×
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-gray-700 font-medium">Public Event</Label>
                      <p className="text-sm text-gray-600">Make this event visible to everyone</p>
                    </div>
                    <Switch
                      checked={formData.isPublic}
                      onCheckedChange={(checked) => handleSwitchChange('isPublic', checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-gray-700 font-medium">Enable Chat</Label>
                      <p className="text-sm text-gray-600">Allow attendees to chat during the event</p>
                    </div>
                    <Switch
                      checked={formData.allowChat}
                      onCheckedChange={(checked) => handleSwitchChange('allowChat', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Submit Button */}
          <div className="flex justify-center">
            <Button 
              type="submit"
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold px-12 py-4 text-lg"
            >
              <Save className="h-5 w-5 mr-2" />
              Create Event
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateEvent;
