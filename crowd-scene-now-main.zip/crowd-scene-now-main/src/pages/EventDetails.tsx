
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, MapPin, Users, Clock, Star, Share2, Heart, MessageCircle, Ticket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import ChatRoom from '@/components/ChatRoom';

const EventDetails = () => {
  const { id } = useParams();
  const [showChat, setShowChat] = useState(false);
  
  // Mock event data - replace with actual API call
  const event = {
    id: '1',
    title: 'Tech Meetup: AI & Machine Learning',
    description: 'Join us for an exciting evening of AI discussions, networking, and hands-on workshops with industry experts. This event will feature presentations from leading AI researchers, interactive demos of the latest ML technologies, and plenty of opportunities to connect with like-minded professionals.\n\nWhat to expect:\n• Keynote presentations on cutting-edge AI research\n• Hands-on workshops with popular ML frameworks\n• Networking sessions with industry professionals\n• Q&A with AI experts\n• Food and refreshments provided',
    date: '2024-06-15',
    time: '18:00',
    endTime: '21:00',
    location: 'TechHub San Francisco, 123 Market Street, San Francisco, CA 94105',
    category: 'Technology',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=400&fit=crop',
    price: 'Free',
    attendees: 45,
    maxAttendees: 100,
    rating: 4.8,
    host: {
      name: 'TechHub SF',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
      bio: 'Leading technology community in San Francisco, organizing events since 2018.',
      eventsHosted: 25
    },
    tags: ['AI', 'Machine Learning', 'Networking', 'Tech', 'Workshop'],
    agenda: [
      { time: '18:00', activity: 'Registration & Welcome Drinks' },
      { time: '18:30', activity: 'Opening Keynote: The Future of AI' },
      { time: '19:15', activity: 'Hands-on ML Workshop Session 1' },
      { time: '20:00', activity: 'Networking Break' },
      { time: '20:30', activity: 'Panel Discussion: AI Ethics' },
      { time: '21:00', activity: 'Closing & Continued Networking' }
    ]
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Hero Image */}
        <div className="relative h-96 rounded-2xl overflow-hidden mb-8 shadow-2xl">
          <img 
            src={event.image} 
            alt={event.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
          
          {/* Floating Action Buttons */}
          <div className="absolute top-6 right-6 flex gap-3">
            <Button size="sm" variant="secondary" className="bg-white/90 hover:bg-white">
              <Share2 className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="secondary" className="bg-white/90 hover:bg-white">
              <Heart className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Event Info Overlay */}
          <div className="absolute bottom-6 left-6 text-white">
            <Badge className="mb-3 bg-purple-600 text-white">{event.category}</Badge>
            <h1 className="text-4xl font-bold mb-2">{event.title}</h1>
            <div className="flex items-center gap-4 text-lg">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                <span>{new Date(event.date).toLocaleDateString('en-US', { 
                  weekday: 'long',
                  month: 'long', 
                  day: 'numeric',
                  year: 'numeric'
                })}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                <span>{event.time} - {event.endTime}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Info */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-purple-100 rounded-full">
                      <MapPin className="h-6 w-6 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Location</p>
                      <p className="text-gray-600 text-sm">{event.location.split(',')[0]}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-blue-100 rounded-full">
                      <Users className="h-6 w-6 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Attendees</p>
                      <p className="text-gray-600 text-sm">{event.attendees} / {event.maxAttendees}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-green-100 rounded-full">
                      <Ticket className="h-6 w-6 text-green-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Price</p>
                      <p className="text-gray-600 text-sm font-bold text-green-600">{event.price}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Description */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">About This Event</CardTitle>
              </CardHeader>
              <CardContent className="p-6 pt-0">
                <div className="prose max-w-none text-gray-700">
                  {event.description.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4 leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
                
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-800 mb-3">Tags</h4>
                  <div className="flex flex-wrap gap-2">
                    {event.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="bg-purple-100 text-purple-700">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Agenda */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-gray-800">Event Agenda</CardTitle>
              </CardHeader>
              <CardContent className="p-6 pt-0">
                <div className="space-y-4">
                  {event.agenda.map((item, index) => (
                    <div key={index} className="flex gap-4 p-4 rounded-lg bg-gray-50">
                      <div className="text-purple-600 font-semibold min-w-[60px]">
                        {item.time}
                      </div>
                      <div className="text-gray-700">{item.activity}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Booking Card */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm sticky top-4">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div className="text-3xl font-bold text-purple-600 mb-2">{event.price}</div>
                  <p className="text-gray-600">per person</p>
                </div>
                
                <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 text-lg mb-4">
                  Book Now
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full border-purple-300 text-purple-600 hover:bg-purple-50 mb-4"
                  onClick={() => setShowChat(!showChat)}
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  {showChat ? 'Hide Chat' : 'Join Discussion'}
                </Button>
                
                <div className="text-center text-sm text-gray-600">
                  <Star className="h-4 w-4 inline mr-1 text-yellow-400 fill-current" />
                  {event.rating} rating • {event.attendees} attending
                </div>
              </CardContent>
            </Card>

            {/* Host Info */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg text-gray-800">Event Host</CardTitle>
              </CardHeader>
              <CardContent className="p-6 pt-0">
                <div className="flex items-start gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={event.host.avatar} />
                    <AvatarFallback>{event.host.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800">{event.host.name}</h4>
                    <p className="text-sm text-gray-600 mb-2">{event.host.bio}</p>
                    <p className="text-xs text-purple-600">{event.host.eventsHosted} events hosted</p>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <Button variant="outline" className="w-full">
                  View Profile
                </Button>
              </CardContent>
            </Card>

            {/* Map Placeholder */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg text-gray-800">Location</CardTitle>
              </CardHeader>
              <CardContent className="p-6 pt-0">
                <div className="h-48 bg-gray-200 rounded-lg flex items-center justify-center mb-4">
                  <MapPin className="h-8 w-8 text-gray-400" />
                  <span className="ml-2 text-gray-500">Map View</span>
                </div>
                <p className="text-sm text-gray-600">{event.location}</p>
                <Button variant="outline" className="w-full mt-3">
                  Get Directions
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Chat Room */}
        {showChat && (
          <div className="mt-8">
            <ChatRoom eventId={event.id} eventTitle={event.title} />
          </div>
        )}
      </div>
    </div>
  );
};

export default EventDetails;
