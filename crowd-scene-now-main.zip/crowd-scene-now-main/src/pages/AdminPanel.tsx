
import React, { useState } from 'react';
import { Check, X, Eye, Calendar, Users, MapPin, Clock, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';

const AdminPanel = () => {
  const [pendingEvents, setPendingEvents] = useState([
    {
      id: '1',
      title: 'Annual Tech Conference 2024',
      description: 'A comprehensive technology conference featuring the latest innovations...',
      host: {
        name: 'TechVentures Inc.',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
        email: 'events@techventures.com'
      },
      date: '2024-07-15',
      time: '09:00',
      location: 'San Francisco Convention Center',
      category: 'Technology',
      maxAttendees: 500,
      ticketPrice: '$99',
      submittedAt: '2024-06-01T10:00:00Z',
      status: 'pending'
    },
    {
      id: '2',
      title: 'Community Garden Workshop',
      description: 'Learn about sustainable gardening practices and community building...',
      host: {
        name: 'Green Community',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c3a1?w=100&h=100&fit=crop&crop=face',
        email: 'hello@greencommunity.org'
      },
      date: '2024-06-30',
      time: '14:00',
      location: 'Central Park Community Garden',
      category: 'Environment',
      maxAttendees: 25,
      ticketPrice: 'Free',
      submittedAt: '2024-06-02T15:30:00Z',
      status: 'pending'
    }
  ]);

  const adminStats = {
    pendingEvents: 12,
    approvedEvents: 145,
    rejectedEvents: 8,
    totalUsers: 2847
  };

  const recentApprovals = [
    {
      id: '3',
      title: 'Startup Pitch Night',
      host: 'Entrepreneur Hub',
      approvedAt: '2024-06-03T09:15:00Z',
      status: 'approved'
    },
    {
      id: '4',
      title: 'Art Gallery Opening',
      host: 'Modern Arts Center',
      approvedAt: '2024-06-02T16:45:00Z',
      status: 'approved'
    }
  ];

  const handleApproveEvent = (eventId: string) => {
    setPendingEvents(prev => 
      prev.map(event => 
        event.id === eventId 
          ? { ...event, status: 'approved' } 
          : event
      ).filter(event => event.status === 'pending')
    );
    console.log('Approved event:', eventId);
  };

  const handleRejectEvent = (eventId: string) => {
    setPendingEvents(prev => 
      prev.map(event => 
        event.id === eventId 
          ? { ...event, status: 'rejected' } 
          : event
      ).filter(event => event.status === 'pending')
    );
    console.log('Rejected event:', eventId);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Manage events and monitor platform activity</p>
          </div>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-500" />
            <span className="text-sm text-gray-600">{pendingEvents.length} events awaiting review</span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-orange-100 rounded-full flex items-center justify-center">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{adminStats.pendingEvents}</div>
              <div className="text-sm text-gray-600">Pending Review</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-green-100 rounded-full flex items-center justify-center">
                <Check className="h-6 w-6 text-green-600" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{adminStats.approvedEvents}</div>
              <div className="text-sm text-gray-600">Approved Events</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-red-100 rounded-full flex items-center justify-center">
                <X className="h-6 w-6 text-red-600" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{adminStats.rejectedEvents}</div>
              <div className="text-sm text-gray-600">Rejected Events</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 mx-auto mb-3 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{adminStats.totalUsers}</div>
              <div className="text-sm text-gray-600">Total Users</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="pending" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="pending">Pending Events</TabsTrigger>
            <TabsTrigger value="recent">Recent Activity</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-6">
            <div className="space-y-6">
              {pendingEvents.map((event) => (
                <Card key={event.id} className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-6">
                      {/* Event Info */}
                      <div className="flex-1 space-y-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-xl font-semibold text-gray-800 mb-2">{event.title}</h3>
                            <p className="text-gray-600 mb-3">{event.description}</p>
                          </div>
                          <Badge className="bg-orange-100 text-orange-700">
                            Pending Review
                          </Badge>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDate(event.date)} at {event.time}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <MapPin className="h-4 w-4" />
                              <span>{event.location}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Users className="h-4 w-4" />
                              <span>Max {event.maxAttendees} attendees</span>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={event.host.avatar} />
                                <AvatarFallback>{event.host.name[0]}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium text-gray-800">{event.host.name}</p>
                                <p className="text-xs text-gray-600">{event.host.email}</p>
                              </div>
                            </div>
                            <div className="text-sm text-gray-600">
                              <span className="font-medium">Category:</span> {event.category}
                            </div>
                            <div className="text-sm text-gray-600">
                              <span className="font-medium">Price:</span> {event.ticketPrice}
                            </div>
                            <div className="text-xs text-gray-500">
                              Submitted: {formatTime(event.submittedAt)}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-col gap-3 min-w-[120px]">
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full"
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </Button>
                        <Button
                          size="sm"
                          className="w-full bg-green-600 hover:bg-green-700 text-white"
                          onClick={() => handleApproveEvent(event.id)}
                        >
                          <Check className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="w-full"
                          onClick={() => handleRejectEvent(event.id)}
                        >
                          <X className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {pendingEvents.length === 0 && (
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                  <CardContent className="p-12 text-center">
                    <Check className="h-16 w-16 mx-auto mb-4 text-green-500" />
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">All caught up!</h3>
                    <p className="text-gray-600">No events pending review at the moment.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="recent" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-gray-800">Recent Approvals</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {recentApprovals.map((event) => (
                  <div key={event.id} className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-800">{event.title}</h4>
                      <p className="text-sm text-gray-600">by {event.host}</p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-100 text-green-700">Approved</Badge>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatTime(event.approvedAt)}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-gray-800">Platform Metrics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Event Approval Rate</span>
                      <span className="text-sm font-medium">94%</span>
                    </div>
                    <Progress value={94} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">User Engagement</span>
                      <span className="text-sm font-medium">87%</span>
                    </div>
                    <Progress value={87} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Platform Health</span>
                      <span className="text-sm font-medium">98%</span>
                    </div>
                    <Progress value={98} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-gray-800">Review Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-800 mb-2">1.2 hrs</div>
                    <div className="text-sm text-gray-600">Average Review Time</div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-green-600">95%</div>
                      <div className="text-xs text-gray-600">Approved</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-red-600">5%</div>
                      <div className="text-xs text-gray-600">Rejected</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminPanel;
