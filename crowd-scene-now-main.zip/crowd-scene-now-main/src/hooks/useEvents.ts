
import { useState, useEffect } from 'react';

interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  category: string;
  image?: string;
  price?: string;
  attendees?: number;
  rating?: number;
  host?: string;
}

export const useEvents = () => {
  const [events, setEvents] = useState<Event[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Mock API call - replace with actual API
    const fetchEvents = async () => {
      setIsLoading(true);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockEvents: Event[] = [
        {
          id: '1',
          title: 'Tech Meetup: AI & Machine Learning',
          description: 'Join us for an exciting evening of AI discussions, networking, and hands-on workshops with industry experts.',
          date: '2024-06-15',
          time: '18:00',
          location: 'San Francisco, CA',
          category: 'Technology',
          image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=500&h=300&fit=crop',
          price: 'Free',
          attendees: 45,
          rating: 4.8,
          host: 'TechHub SF'
        },
        {
          id: '2',
          title: 'Sunset Jazz Festival',
          description: 'Experience the best local jazz musicians in a beautiful outdoor setting as the sun sets over the city.',
          date: '2024-06-20',
          time: '19:30',
          location: 'Golden Gate Park, SF',
          category: 'Music',
          image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=500&h=300&fit=crop',
          price: '$25',
          attendees: 120,
          rating: 4.9,
          host: 'SF Jazz Society'
        },
        {
          id: '3',
          title: 'Food Truck Rally',
          description: 'Discover amazing local cuisine from 20+ food trucks, live music, and family-friendly activities.',
          date: '2024-06-18',
          time: '12:00',
          location: 'Mission Bay, SF',
          category: 'Food',
          image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=500&h=300&fit=crop',
          price: 'Free',
          attendees: 200,
          rating: 4.7,
          host: 'Mission Bay Events'
        },
        {
          id: '4',
          title: 'Startup Networking Night',
          description: 'Connect with entrepreneurs, investors, and fellow startup enthusiasts in the heart of Silicon Valley.',
          date: '2024-06-22',
          time: '18:30',
          location: 'Palo Alto, CA',
          category: 'Business',
          image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=500&h=300&fit=crop',
          price: '$15',
          attendees: 80,
          rating: 4.6,
          host: 'Silicon Valley Entrepreneurs'
        },
        {
          id: '5',
          title: 'Morning Yoga in the Park',
          description: 'Start your day with peaceful yoga practice surrounded by nature. All levels welcome!',
          date: '2024-06-16',
          time: '08:00',
          location: 'Dolores Park, SF',
          category: 'Sports',
          image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500&h=300&fit=crop',
          price: '$10',
          attendees: 30,
          rating: 4.8,
          host: 'SF Wellness Community'
        },
        {
          id: '6',
          title: 'Digital Art Exhibition',
          description: 'Explore cutting-edge digital art installations and interactive experiences from emerging artists.',
          date: '2024-06-25',
          time: '15:00',
          location: 'SOMA District, SF',
          category: 'Art',
          image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=300&fit=crop',
          price: '$20',
          attendees: 60,
          rating: 4.5,
          host: 'Digital Arts Collective'
        }
      ];
      
      setEvents(mockEvents);
      setIsLoading(false);
    };

    fetchEvents();
  }, []);

  return { events, isLoading };
};
