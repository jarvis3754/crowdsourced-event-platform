
import React from 'react';
import { Calendar, MapPin, Users, Clock, Star, Heart } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

interface Event {
  id?: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  category: string;
  image?: string;
  price?: string;
  attendees?: number;
  rating?: number;
  host?: string;
}

interface EventCardProps {
  event: Event;
  featured?: boolean;
}

const EventCard: React.FC<EventCardProps> = ({ event, featured = false }) => {
  const mockEvent = {
    id: '1',
    title: 'Tech Meetup: AI & Machine Learning',
    description: 'Join us for an exciting evening of AI discussions and networking',
    date: '2024-06-15',
    time: '18:00',
    location: 'San Francisco, CA',
    category: 'Technology',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=500&h=300&fit=crop',
    price: 'Free',
    attendees: 45,
    rating: 4.8,
    host: 'TechHub SF'
  };

  const eventData = { ...mockEvent, ...event };

  return (
    <Card className={`group overflow-hidden border-0 bg-white shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 ${featured ? 'ring-2 ring-purple-200' : ''}`}>
      <div className="relative overflow-hidden">
        {featured && (
          <Badge className="absolute top-4 left-4 z-10 bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-semibold">
            Featured
          </Badge>
        )}
        <div className="absolute top-4 right-4 z-10">
          <Button size="sm" variant="ghost" className="h-8 w-8 rounded-full bg-white/80 hover:bg-white">
            <Heart className="h-4 w-4 text-gray-600 hover:text-red-500 transition-colors" />
          </Button>
        </div>
        
        <div className="h-48 bg-gradient-to-br from-purple-400 via-blue-500 to-indigo-600 relative overflow-hidden">
          {eventData.image && (
            <img 
              src={eventData.image} 
              alt={eventData.title}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          
          {/* Category Badge */}
          <Badge className="absolute bottom-4 left-4 bg-white/90 text-purple-700 font-medium">
            {eventData.category}
          </Badge>
          
          {/* Price Badge */}
          <Badge className="absolute bottom-4 right-4 bg-green-500 text-white font-semibold">
            {eventData.price}
          </Badge>
        </div>
      </div>

      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-purple-600 transition-colors line-clamp-2">
              {eventData.title}
            </h3>
            <p className="text-gray-600 text-sm line-clamp-2">{eventData.description}</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center text-gray-600 text-sm">
              <Calendar className="h-4 w-4 mr-2 text-purple-500" />
              <span>{new Date(eventData.date).toLocaleDateString('en-US', { 
                weekday: 'short',
                month: 'short', 
                day: 'numeric'
              })}</span>
              <Clock className="h-4 w-4 ml-4 mr-2 text-purple-500" />
              <span>{eventData.time}</span>
            </div>
            
            <div className="flex items-center text-gray-600 text-sm">
              <MapPin className="h-4 w-4 mr-2 text-purple-500" />
              <span className="truncate">{eventData.location}</span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center text-gray-600 text-sm">
                <Users className="h-4 w-4 mr-2 text-purple-500" />
                <span>{eventData.attendees} attending</span>
              </div>
              
              {eventData.rating && (
                <div className="flex items-center text-sm">
                  <Star className="h-4 w-4 mr-1 text-yellow-400 fill-current" />
                  <span className="text-gray-600">{eventData.rating}</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-gray-100">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Hosted by <span className="font-medium text-gray-700">{eventData.host}</span>
              </div>
              <Link to={`/events/${eventData.id}`}>
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium px-6 transition-all duration-300"
                >
                  View Details
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EventCard;
