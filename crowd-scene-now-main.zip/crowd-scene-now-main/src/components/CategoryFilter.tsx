
import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Monitor, Music, Utensils, Dumbbell, Briefcase, Calendar } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  count: number;
}

interface CategoryFilterProps {
  categories: Category[];
  selectedCategory: string;
  onCategoryChange: (categoryId: string) => void;
}

const CategoryFilter: React.FC<CategoryFilterProps> = ({
  categories,
  selectedCategory,
  onCategoryChange
}) => {
  const getCategoryIcon = (categoryId: string) => {
    switch (categoryId) {
      case 'tech':
        return Monitor;
      case 'music':
        return Music;
      case 'food':
        return Utensils;
      case 'sports':
        return Dumbbell;
      case 'business':
        return Briefcase;
      default:
        return Calendar;
    }
  };

  const getCategoryGradient = (categoryId: string, isSelected: boolean) => {
    if (isSelected) {
      switch (categoryId) {
        case 'tech':
          return 'bg-gradient-to-r from-blue-500 to-cyan-500';
        case 'music':
          return 'bg-gradient-to-r from-pink-500 to-rose-500';
        case 'food':
          return 'bg-gradient-to-r from-orange-500 to-red-500';
        case 'sports':
          return 'bg-gradient-to-r from-green-500 to-emerald-500';
        case 'business':
          return 'bg-gradient-to-r from-gray-700 to-gray-900';
        default:
          return 'bg-gradient-to-r from-purple-500 to-indigo-500';
      }
    }
    return 'bg-white hover:bg-gray-50';
  };

  return (
    <div className="flex flex-wrap gap-4 justify-center">
      {categories.map((category) => {
        const Icon = getCategoryIcon(category.id);
        const isSelected = selectedCategory === category.id;
        const gradientClass = getCategoryGradient(category.id, isSelected);
        
        return (
          <Button
            key={category.id}
            variant={isSelected ? "default" : "outline"}
            size="lg"
            onClick={() => onCategoryChange(category.id)}
            className={`
              ${gradientClass}
              ${isSelected 
                ? 'text-white border-0 shadow-lg transform scale-105' 
                : 'text-gray-700 border-gray-200 hover:border-purple-300'
              }
              transition-all duration-300 rounded-full px-6 py-3 font-medium
              flex items-center gap-3 min-w-[140px] justify-between
              hover:shadow-lg hover:transform hover:scale-105
            `}
          >
            <div className="flex items-center gap-2">
              <Icon className="h-5 w-5" />
              <span>{category.name}</span>
            </div>
            <Badge 
              variant="secondary" 
              className={`
                ${isSelected 
                  ? 'bg-white/20 text-white border-0' 
                  : 'bg-purple-100 text-purple-700'
                }
                ml-2 rounded-full px-2 py-1 text-xs font-semibold
              `}
            >
              {category.count}
            </Badge>
          </Button>
        );
      })}
    </div>
  );
};

export default CategoryFilter;
