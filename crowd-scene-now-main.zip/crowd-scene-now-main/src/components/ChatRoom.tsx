
import React, { useState, useEffect, useRef } from 'react';
import { Send, Users, Smile } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

interface ChatRoomProps {
  eventId: string;
  eventTitle: string;
}

interface Message {
  id: string;
  userId: string;
  username: string;
  avatar?: string;
  message: string;
  timestamp: Date;
}

interface Participant {
  id: string;
  username: string;
  avatar?: string;
  isOnline: boolean;
}

const ChatRoom: React.FC<ChatRoomProps> = ({ eventId, eventTitle }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [participants, setParticipants] = useState<Participant[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Mock current user
  const currentUser = {
    id: 'user1',
    username: 'John Doe',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face'
  };

  // Mock initial data
  useEffect(() => {
    const mockMessages: Message[] = [
      {
        id: '1',
        userId: 'user2',
        username: 'Sarah Wilson',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c3a1?w=100&h=100&fit=crop&crop=face',
        message: 'Hey everyone! Really excited for this event 🎉',
        timestamp: new Date(Date.now() - 5 * 60000)
      },
      {
        id: '2',
        userId: 'user3',
        username: 'Mike Chen',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
        message: 'Same here! Has anyone been to one of these meetups before?',
        timestamp: new Date(Date.now() - 3 * 60000)
      },
      {
        id: '3',
        userId: 'user4',
        username: 'Emma Davis',
        message: 'Yes! The last one was amazing. Great networking opportunities!',
        timestamp: new Date(Date.now() - 2 * 60000)
      },
      {
        id: '4',
        userId: 'user2',
        username: 'Sarah Wilson',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c3a1?w=100&h=100&fit=crop&crop=face',
        message: 'Perfect! Looking forward to the hands-on workshops 💻',
        timestamp: new Date(Date.now() - 1 * 60000)
      }
    ];

    const mockParticipants: Participant[] = [
      { id: 'user1', username: 'John Doe (You)', avatar: currentUser.avatar, isOnline: true },
      { id: 'user2', username: 'Sarah Wilson', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612c3a1?w=100&h=100&fit=crop&crop=face', isOnline: true },
      { id: 'user3', username: 'Mike Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face', isOnline: true },
      { id: 'user4', username: 'Emma Davis', isOnline: false },
      { id: 'user5', username: 'Alex Johnson', isOnline: true },
      { id: 'user6', username: 'Lisa Brown', isOnline: false }
    ];

    setMessages(mockMessages);
    setParticipants(mockParticipants);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: Date.now().toString(),
        userId: currentUser.id,
        username: currentUser.username,
        avatar: currentUser.avatar,
        message: newMessage.trim(),
        timestamp: new Date()
      };

      setMessages(prev => [...prev, message]);
      setNewMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: false
    });
  };

  return (
    <Card className="border-0 shadow-lg bg-white/90 backdrop-blur-sm">
      <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-full">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Event Discussion</h3>
              <p className="text-sm text-purple-100">{eventTitle}</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-white/20 text-white border-0">
            {participants.filter(p => p.isOnline).length} online
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="p-0">
        <div className="grid lg:grid-cols-4 h-96">
          {/* Messages Area */}
          <div className="lg:col-span-3 flex flex-col">
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((message) => (
                <div key={message.id} className={`flex gap-3 ${message.userId === currentUser.id ? 'flex-row-reverse' : ''}`}>
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src={message.avatar} />
                    <AvatarFallback>{message.username[0]}</AvatarFallback>
                  </Avatar>
                  
                  <div className={`flex flex-col max-w-xs lg:max-w-md ${message.userId === currentUser.id ? 'items-end' : ''}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium text-gray-700">
                        {message.userId === currentUser.id ? 'You' : message.username}
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatTime(message.timestamp)}
                      </span>
                    </div>
                    
                    <div className={`
                      px-3 py-2 rounded-lg text-sm
                      ${message.userId === currentUser.id 
                        ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white' 
                        : 'bg-white text-gray-800 border border-gray-200'
                      }
                    `}>
                      {message.message}
                    </div>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="p-4 border-t bg-white">
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="pr-10"
                  />
                  <Button
                    size="sm"
                    variant="ghost"
                    className="absolute right-1 top-1 h-8 w-8 p-0"
                  >
                    <Smile className="h-4 w-4 text-gray-400" />
                  </Button>
                </div>
                <Button 
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Participants Sidebar */}
          <div className="border-l bg-white p-4">
            <h4 className="font-semibold text-gray-800 mb-3">
              Participants ({participants.length})
            </h4>
            <div className="space-y-2">
              {participants.map((participant) => (
                <div key={participant.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-gray-50">
                  <div className="relative">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={participant.avatar} />
                      <AvatarFallback>{participant.username[0]}</AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white ${
                      participant.isOnline ? 'bg-green-400' : 'bg-gray-300'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">
                      {participant.username}
                    </p>
                    <p className="text-xs text-gray-500">
                      {participant.isOnline ? 'Online' : 'Offline'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ChatRoom;
